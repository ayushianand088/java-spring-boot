package com.spring_boot.learncoding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearncodingApplicationTests {

	@Test
	void contextLoads() {
	}

}
